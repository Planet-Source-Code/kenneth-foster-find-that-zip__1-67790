This simple code makes a custom OCX guage
Use the min, max, and value properties to customize your guage
The supplied tester project demonstrates how you may use the OCX.

Feel free to use this code however you wish...

diaa,

diaa1972@gmail.com