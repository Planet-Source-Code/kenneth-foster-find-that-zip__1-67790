Title: GetPath
Description: Do you use different functions to extract Filename, Filepath, or Extension from a path. GetPath is a function that can extract 9 different parts from a path. It can extract FileName, JustName, FileExtension, FilePath, Drive, LastFolder, FirstFolder, LastFolderAndFileName and DriveAndFirstFolder. It supports relative paths too. Try to parse "C:\Look\At\The\FileExtension\Of\This\Path.exe\" to your GetExtension function and then it to my GetPath function. Also try "C:\Temp\Is\A\File\Not\A\Folder\Temp". You will know the difference. I will feel glad to hear your comments and suggestions.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=67695&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
